/* ============================================================
   MolParam — script.js
   ============================================================ */

const fileInput     = document.getElementById("fileInput");
const dropzone      = document.getElementById("dropzone");
const fileInfo      = document.getElementById("fileInfo");
const btnPredict    = document.getElementById("btnPredict");
const loader        = document.getElementById("loader");
const errorBox      = document.getElementById("errorBox");
const resultsSection= document.getElementById("resultsSection");

let currentFile = null;
let currentData = null;

// ── Drag & drop ──────────────────────────────────────────────
dropzone.addEventListener("dragover", (e) => {
  e.preventDefault();
  dropzone.classList.add("dragover");
});

dropzone.addEventListener("dragleave", () => dropzone.classList.remove("dragover"));

dropzone.addEventListener("drop", (e) => {
  e.preventDefault();
  dropzone.classList.remove("dragover");
  const file = e.dataTransfer.files[0];
  if (file) handleFile(file);
});

dropzone.addEventListener("click", (e) => {
  if (e.target !== fileInput) fileInput.click();
});

fileInput.addEventListener("change", () => {
  if (fileInput.files[0]) handleFile(fileInput.files[0]);
});

function handleFile(file) {
  if (!file.name.endsWith(".mol2")) {
    showError("El archivo debe tener extensión .mol2");
    return;
  }
  currentFile = file;
  fileInfo.style.display = "block";
  fileInfo.textContent   = `✔ ${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
  btnPredict.disabled    = false;
  hideResults();
  hideError();
}

// ── Predict ──────────────────────────────────────────────────
btnPredict.addEventListener("click", async () => {
  if (!currentFile) return;

  showLoader();
  hideResults();
  hideError();

  const formData = new FormData();
  formData.append("mol2file", currentFile);

  try {
    const res  = await fetch("/predict", { method: "POST", body: formData });
    const data = await res.json();

    if (data.error) {
      showError(data.error);
    } else {
      currentData = data;
      renderResults(data);
    }
  } catch (err) {
    showError("Error de conexión con el servidor: " + err.message);
  } finally {
    hideLoader();
  }
});

// ── Render ───────────────────────────────────────────────────
function renderResults(data) {
  document.getElementById("molName").textContent = data.molecule;
  renderTable("AA", data.AA);
  renderTable("UA", data.UA);
  resultsSection.style.display = "block";
}

function renderTable(scheme, rows) {
  const tbody = document.querySelector(`#table${scheme} tbody`);
  const stats = document.getElementById(`stats${scheme}`);
  tbody.innerHTML = "";

  if (!rows || rows.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:var(--text-muted);padding:2rem">Sin átomos para este esquema</td></tr>`;
    stats.innerHTML = "";
    return;
  }

  // Stats
  const nAtoms   = rows.length;
  const types    = [...new Set(rows.map(r => r.atomtype_predicho))].length;
  const charges  = rows.map(r => r.charge_predicha);
  const avgCharge= (charges.reduce((a,b) => a+b, 0) / charges.length).toFixed(3);
  const minC     = Math.min(...charges).toFixed(3);
  const maxC     = Math.max(...charges).toFixed(3);

  stats.innerHTML = `
    <div class="stat-chip">Átomos: <span>${nAtoms}</span></div>
    <div class="stat-chip">Clases atomtype: <span>${types}</span></div>
    <div class="stat-chip">Charge media: <span>${avgCharge} e</span></div>
    <div class="stat-chip">Rango: <span>[${minC}, ${maxC}] e</span></div>
  `;

  // Rows
  rows.forEach(row => {
    const charge = parseFloat(row.charge_predicha);
    const chargeClass = charge > 0.05 ? "charge-pos" : charge < -0.05 ? "charge-neg" : "charge-neu";
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${row.molecule}</td>
      <td>${row.atom_id}</td>
      <td>${row.atom_name}</td>
      <td>${row.element}</td>
      <td class="atomtype">${row.atomtype_predicho}</td>
      <td class="${chargeClass}">${charge >= 0 ? "+" : ""}${charge.toFixed(4)}</td>
    `;
    tbody.appendChild(tr);
  });
}

// ── Tabs ─────────────────────────────────────────────────────
document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    document.querySelectorAll(".tab-content").forEach(c => c.classList.remove("active"));
    tab.classList.add("active");
    document.getElementById(`tab-${tab.dataset.tab}`).classList.add("active");
  });
});

// ── Download CSV ─────────────────────────────────────────────
document.getElementById("downloadAA").addEventListener("click", () => {
  if (currentData) downloadCSV(currentData.AA, `${currentData.molecule}_AA.csv`);
});

document.getElementById("downloadUA").addEventListener("click", () => {
  if (currentData) downloadCSV(currentData.UA, `${currentData.molecule}_UA.csv`);
});

function downloadCSV(rows, filename) {
  if (!rows || rows.length === 0) return;
  const headers = Object.keys(rows[0]).join(",");
  const lines   = rows.map(r => Object.values(r).join(","));
  const csv     = [headers, ...lines].join("\n");
  const blob    = new Blob([csv], { type: "text/csv" });
  const url     = URL.createObjectURL(blob);
  const a       = document.createElement("a");
  a.href        = url;
  a.download    = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// ── Helpers ──────────────────────────────────────────────────
function showLoader()  { loader.style.display = "block"; }
function hideLoader()  { loader.style.display = "none";  }
function hideResults() { resultsSection.style.display = "none"; }
function hideError()   { errorBox.style.display = "none"; }

function showError(msg) {
  errorBox.style.display = "block";
  errorBox.textContent   = "⚠ " + msg;
}
